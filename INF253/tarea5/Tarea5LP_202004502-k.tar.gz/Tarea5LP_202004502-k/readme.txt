Nombre: Diego Eduardo Paz Letelier
Rol: 202004502-k

En la 4 conseguí hacer las clausulas para que sea verdadero en el caso de 1 nodo y sus hijos, 
pero no se hasta que punto la clausula de recursividad funciona, en teoria deberia funcionar bien 
ya que todos los casos de prueba que le puse dieron el resultado correcto, pero no estoy seguro :(